self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"0a95f675412a4b1c6d18f745c10e40dc6f4d4a5e",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });