self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"68f4747994fd84bd2ef965c93ee3b009a3b52b72",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });