self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"11c058ac6014842a9098443b7b8f304ad6d2d467",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });