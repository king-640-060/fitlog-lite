self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"0af60a6d1969c7fbf8eed1b035d92a333fb51e48",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });