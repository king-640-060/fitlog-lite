self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"d8b08b74e17e91139239f1d6d939ddd9b1d7030c",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });