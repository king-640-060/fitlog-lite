self.addEventListener('message', event => {
      if (event.data?.type !== 'FITLOG_SW_DIAGNOSTICS' || !event.ports?.[0]) return;
      event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(clients => {
        event.ports[0].postMessage({build:"e082689dce56f7fcdfd055c4709b93fafafd7819",clients:clients.filter(client => client.url.startsWith(self.registration.scope)).length});
      }));
    });