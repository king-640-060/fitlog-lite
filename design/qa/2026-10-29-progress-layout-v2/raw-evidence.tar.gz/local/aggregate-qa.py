from pathlib import Path
import json,hashlib
w=Path(__file__).parent;r=Path('/Users/zhaozhantian/Documents/Codex/2026-09-24/files-pasted-by-the-user-king/work/fitlog-lite');expected=json.loads((w/'candidate-source.json').read_text());calls={};attempts=[];artifacts=[]
for folder in sorted((w/'remote-raw').glob('progress-layout-v2-shard-*')):
 if not(folder/'download.complete').exists():continue
 assert json.loads((folder/'.qa-remote/source-manifest.json').read_text())==expected
 data=json.loads((folder/'qa-results/results.json').read_text());artifacts.append(folder.name)
 for a in data['results']:attempts.append(dict(a,artifact=folder.name,sourceCommit=data['commit']))
def add(folder,replace=False):
 d=json.loads((folder/'qa-results/results.json').read_text())
 for a in d['results']:
  key=a['name']
  if '-retake-joint-'in folder.name:key+='-'+folder.name.rsplit('-',1)[-1]
  calls[key]=dict(a,effectiveKey=key,artifact=folder.name,sourceCommit=d['commit'])
for p in sorted((w/'remote-raw').glob('progress-layout-v2-shard-regression-*')):add(p)
for p in sorted((w/'remote-raw').glob('progress-layout-v2-shard-final-*')):add(p)
retakes=list((w/'remote-raw').glob('progress-layout-v2-shard-retake-*'));assert len([p for p in retakes if(p/'download.complete').exists()])==14,'retake evidence incomplete'
for p in sorted(retakes):add(p)
scroll=list((w/'remote-raw').glob('progress-layout-v2-shard-scroll-origin-v09-edges'));assert len(scroll)==1 and(scroll[0]/'download.complete').exists(),'scroll-origin CI incomplete'
add(scroll[0])
assert all(x['status']=='PASS'for x in calls.values()),[(k,x['status'])for k,x in calls.items()if x['status']!='PASS']
for x in calls.values():
 actual=hashlib.sha256((r/'tests/browser'/(x['file']+'.mjs')).read_bytes()).hexdigest()
 assert x['testSourceSha']==actual,(x['effectiveKey'],'driver differs')
old=json.loads((r/'design/qa/2026-10-26-interaction-v09/regressions/effective-coverage.json').read_text());assert {x['name']for x in old['results']}<={x['name']for x in calls.values()}
summary={'status':'PASS','effectiveSuiteCalls':len(calls),'notIndependentFeatures':True,'all181SourceFilesExact':True,'original75UniqueGateNamesRetained':True,'results':list(calls.values()),'attempts':attempts,'artifacts':artifacts,'initialFailuresRetained':4,'retakeOriginFailureRetained':1,'physicalIPhone':'Pending'}
(w/'effective-coverage.json').write_text(json.dumps(summary,indent=2));print('PASS',len(calls),'effective suite calls,',len(attempts),'attempt records,',len(artifacts),'source manifests')
